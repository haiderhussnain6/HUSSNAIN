#include "audio.h"
#include <Windows.h>
#include <MMsystem.h>
#include <iostream>
using namespace std;

int main()
{
	int option = 0;
	audios aud;
	aud.display();
	cout << endl << endl;
	while (1)
	{
		cout << "\t\t\tENTER YOUR DESIRED NUMBER HERE: ";
		cin >> option;
		if (option == 1)
		{
			aud.Play_Audio_one();
		}
		if (option == 2)
		{
			aud.Play_Audio_two();
		}
		if (option == 3)
		{
			aud.Play_Audio_three();
		}
		if (option == 4)
		{
			aud.Play_Audio_four();
		}
		if (option == 5)
		{
			aud.Play_Audio_five();
		}
		if (option == 6)
		{
			aud.Play_Audio_six();
		}
		if (option == 7)
		{
			aud.Play_Audio_seven();
		}
		if (option == 8)
		{
			aud.Play_Audio_eight();
		}
		if (option == 9)
		{
			aud.Play_Audio_nine();
		}
		if (option == 10)
		{
			aud.Play_Audio_ten();
		}
		if (option == 0)
		{
			return 0;
		}
		if (option > 10)
		{
			cout << "\n\n\t\t\tINVALID INPUT..!! PLEASE USE ANOTHER OPTION OR 0 TO EXIT.\n\n";
		}
	}
	return 0;
}