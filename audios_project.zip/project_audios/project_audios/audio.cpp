#include "audio.h"
#include <Windows.h>
#include <MMsystem.h>
#include <iostream>
using namespace std;

void audios::Play_Audio_one(){ PlaySound(TEXT("J_Balvin_Willy_William_-_Mi_Gente_Official_Video[Mp3Converter.net].wav"), NULL, SND_SYNC); }
void audios::Play_Audio_two(){ PlaySound(TEXT("j bushrit khair_mi_feat abela.wav"), NULL, SND_SYNC); }
void audios::Play_Audio_three(){ PlaySound(TEXT("Silva Gunbardhi ft. Mandi ft. Dafi - Te ka lali shpirt  (Official Video HD) (320  kbps) (Mp3Converter.net).wav"), NULL, SND_SYNC); }
void audios::Play_Audio_four(){ PlaySound(TEXT("Jason_Derulo_-_Swalla_feat_Nicki_Minaj_Ty_Dolla_ign_Official_Lyric_Video[Mp3Converter.net].wav"), NULL, SND_SYNC); }
void audios::Play_Audio_five(){ PlaySound(TEXT("Major_Lazer_DJ_Snake_-_Lean_On_feat_M�_Official_Music_Video[Mp3Converter.net].wav"), NULL, SND_SYNC); }
void audios::Play_Audio_six(){ PlaySound(TEXT("Clean_Bandit_-_Rockabye_ft_Sean_Paul_Anne-Marie_Official_Video.wav"), NULL, SND_SYNC); }
void audios::Play_Audio_seven(){ PlaySound(TEXT("Ed_Sheeran_-_Shape_of_You_Official_Video[Mp3Converter.net].wav"), NULL, SND_SYNC); }
void audios::Play_Audio_eight(){ PlaySound(TEXT("Shakira_-_Chantaje_ft_Maluma[Mp3Converter.net].wav"), NULL, SND_SYNC); }
void audios::Play_Audio_nine(){ PlaySound(TEXT("Sia_-_Cheap_Thrills_Lyrics[Mp3Converter.net].wav"), NULL, SND_SYNC); }
void audios::Play_Audio_ten(){ PlaySound(TEXT("Teriyaki_Boyz_-_Tokyo_Drift_KVSH_REMIX_INFINITY_enjoybeauty[Mp3Converter.net]a.wav"), NULL, SND_SYNC); }
void audios::display()
{
	cout << "\t\t\tHERE IS A LIST OF SONGS...\n\n";
	cout << "\t\tPRESS 1 to play         Balvin\n";
	cout << "\t\tPRESS 2 to play         Bushrit Khair\n";
	cout << "\t\tPRESS 3 to play         Silva\n";
	cout << "\t\tPRESS 4 to play         Swalla\n";
	cout << "\t\tPRESS 5 to play         Leon on\n";
	cout << "\t\tPRESS 6 to play         Rockabye\n";
	cout << "\t\tPRESS 7 to play         Shape of you\n";
	cout << "\t\tPRESS 8 to play         Chantaje\n";
	cout << "\t\tPRESS 9 to play         Sia cheap\n";
	cout << "\t\tPRESS 10 to play        Kvsh Infinity\n";
	cout << "\t\tPRESS 0 to exit.....\n";
}