#pragma once

class audios
{
public:
	void Play_Audio_one();
	void Play_Audio_two();
	void Play_Audio_three();
	void Play_Audio_four();
	void Play_Audio_five();
	void Play_Audio_six();
	void Play_Audio_seven();
	void Play_Audio_eight();
	void Play_Audio_nine();
	void Play_Audio_ten();

	void display();
};